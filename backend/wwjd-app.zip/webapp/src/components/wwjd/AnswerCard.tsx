import { Link } from "react-router-dom";
import { CrossIcon } from "./CrossIcon";
import { useLanguage } from "@/context/LanguageContext";

interface AnswerCardProps {
  question: string;
  answer: string;
  verses?: string[];
}

export function AnswerCard({ question, answer, verses }: AnswerCardProps) {
  const { t } = useLanguage();

  return (
    <div className="w-full max-w-2xl mx-auto animate-fade-in">
      <div className="bg-card rounded-xl border border-border/50 overflow-hidden shadow-sm">
        {/* Question section */}
        <div className="px-6 py-4 bg-secondary/30 border-b border-border/30">
          <p className="text-sm text-muted-foreground mb-1">{t('yourQuestion')}</p>
          <p className="font-medium">{question}</p>
        </div>

        {/* Answer section */}
        <div className="px-6 py-6">
          <div className="flex items-start gap-4">
            <div className="flex-shrink-0 w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
              <CrossIcon className="w-5 h-5 text-primary" />
            </div>
            <div className="flex-1">
              <p className="text-lg font-cormorant leading-relaxed whitespace-pre-wrap">
                {answer}
              </p>
            </div>
          </div>
        </div>

        {/* Bible verses section */}
        {verses && verses.length > 0 ? (
          <div className="px-6 py-4 bg-muted/30 border-t border-border/30">
            <p className="text-xs text-muted-foreground uppercase tracking-wide mb-2">
              {t('relatedScripture')}
            </p>
            <div className="flex flex-wrap gap-2">
              {verses.map((verse, index) => (
                <Link
                  key={index}
                  to={`/verses?ref=${encodeURIComponent(verse)}`}
                  className="inline-block px-3 py-1 text-sm bg-primary/10 text-primary rounded-full font-medium hover:bg-primary/20 transition-colors cursor-pointer"
                >
                  {verse}
                </Link>
              ))}
            </div>
          </div>
        ) : null}
      </div>
    </div>
  );
}
