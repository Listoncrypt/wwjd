import { useState, useEffect } from "react";
import { CrossIcon } from "@/components/wwjd/CrossIcon";
import { QuestionInput } from "@/components/wwjd/QuestionInput";
import { AnswerCard } from "@/components/wwjd/AnswerCard";
import { LoadingState } from "@/components/wwjd/LoadingState";
import { ExampleQuestions } from "@/components/wwjd/ExampleQuestions";
import { ThemeToggle } from "@/components/ThemeToggle";
import { LanguageSelector } from "@/components/LanguageSelector";
import { useToast } from "@/hooks/use-toast";
import { useLanguage } from "@/context/LanguageContext";
import { api } from "@/lib/api";
import { Twitter } from "lucide-react";

const INSPIRATIONAL_VERSES = [
  { text: "Ask, and it shall be given you", reference: "Matthew 7:7" },
  { text: "For I know the plans I have for you", reference: "Jeremiah 29:11" },
  { text: "I can do all things through Christ who strengthens me", reference: "Philippians 4:13" },
  { text: "The Lord is my shepherd; I shall not want", reference: "Psalm 23:1" },
  { text: "Be strong and courageous", reference: "Joshua 1:9" },
  { text: "Trust in the Lord with all your heart", reference: "Proverbs 3:5" },
  { text: "The truth shall set you free", reference: "John 8:32" },
  { text: "Love one another as I have loved you", reference: "John 15:12" },
];

interface Answer {
  question: string;
  answer: string;
  verses: string[];
}

const Index = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [currentAnswer, setCurrentAnswer] = useState<Answer | null>(null);
  const [verseIndex, setVerseIndex] = useState(0);
  const { toast } = useToast();
  const { t, language } = useLanguage();

  const currentVerse = INSPIRATIONAL_VERSES[verseIndex];

  // Auto-rotate verses every 5 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      setVerseIndex((prev) => (prev + 1) % INSPIRATIONAL_VERSES.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const handleAskQuestion = async (question: string) => {
    setIsLoading(true);
    setCurrentAnswer(null);

    try {
      // Use backend API
      const result = await api.post<{ answer: string; verses: string[] }>('/api/ask', {
        question,
        language,
      });

      setCurrentAnswer({
        question,
        answer: result.answer,
        verses: result.verses || [],
      });
    } catch (error) {
      toast({
        title: "Something went wrong",
        description: "Please try again in a moment.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Subtle background pattern */}
      <div
        className="fixed inset-0 pointer-events-none opacity-[0.015]"
        style={{
          backgroundImage: `radial-gradient(circle at 1px 1px, currentColor 1px, transparent 0)`,
          backgroundSize: "32px 32px",
        }}
      />

      {/* Main content */}
      <div className="relative z-10 px-4 py-8 md:py-16">
        {/* Theme and Language toggles */}
        <div className="absolute top-4 right-4 md:top-8 md:right-8 flex items-center gap-2">
          <LanguageSelector />
          <ThemeToggle />
        </div>

        {/* Header */}
        <header className="text-center mb-12 md:mb-16">
          <div className="flex items-center justify-center gap-3 mb-4">
            <CrossIcon className="w-8 h-8 md:w-10 md:h-10 text-primary" />
          </div>
          <h1 className="font-cormorant text-4xl md:text-5xl lg:text-6xl font-semibold tracking-tight mb-3">
            {t('title')}
          </h1>
          <p className="text-muted-foreground text-lg md:text-xl font-cormorant italic transition-opacity duration-500">
            "{currentVerse.text}" — {currentVerse.reference}
          </p>
          <div className="flex justify-center gap-1 mt-3">
            {INSPIRATIONAL_VERSES.map((_, idx) => (
              <span
                key={idx}
                className={`w-1.5 h-1.5 rounded-full transition-colors ${
                  idx === verseIndex ? "bg-primary" : "bg-muted-foreground/30"
                }`}
              />
            ))}
          </div>
        </header>

        {/* Question input */}
        <div className="mb-8">
          <QuestionInput onSubmit={handleAskQuestion} isLoading={isLoading} />
        </div>

        {/* Loading state */}
        {isLoading ? (
          <div className="mb-8">
            <LoadingState />
          </div>
        ) : null}

        {/* Answer display */}
        {currentAnswer && !isLoading ? (
          <div className="mb-12">
            <AnswerCard
              question={currentAnswer.question}
              answer={currentAnswer.answer}
              verses={currentAnswer.verses}
            />
          </div>
        ) : null}

        {/* Example questions (show when no answer displayed) */}
        {!currentAnswer && !isLoading ? (
          <div className="mt-12">
            <ExampleQuestions onSelect={handleAskQuestion} />
          </div>
        ) : null}

        {/* Footer */}
        <footer className="text-center mt-16 md:mt-24">
          <p className="text-sm text-muted-foreground mb-4">
            {t('footerText')}
          </p>
          <a
            href="https://x.com/listoncrypt"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center w-10 h-10 rounded-full bg-muted hover:bg-muted/80 transition-colors"
          >
            <Twitter className="w-5 h-5 text-muted-foreground" />
          </a>
        </footer>
      </div>
    </div>
  );
};

export default Index;
